import azure.cognitiveservices.speech as speechsdk
from azure.cognitiveservices.speech import AudioDataStream, SpeechConfig, SpeechSynthesizer, SpeechSynthesisOutputFormat
from azure.cognitiveservices.speech.audio import AudioOutputConfig
import json
from urllib import request as req

speech_config = SpeechConfig(subscription="25eb8d0da8934f59a33b6e174dd44beb", region="eastus")
speech_config.speech_synthesis_voice_name="en-CA-ClaraNeural"
speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)


def speak(text):
    try:
        result = speech_synthesizer.speak_text_async(text).get()
    except:
        print('error')


print("Type some text that you want to speak...")
ct = input("Enter City : ")

response=req.urlopen('http://api.openweathermap.org/data/2.5/weather?q='+ct+'&appid=5ea9269ece0f0c287803a5b69fca4d80')

respdata=response.read()
info=json.loads(respdata)
print(info)
print('-'*50)

speak("According to openweathermap server")
print("Weather description at "+ct+" is "+ str(info["weather"][0]["description"]))

k=info["main"]["temp"]
kfeel=info["main"]["feels_like"]
cel=k-273.15
celfeel=kfeel-273.15
print("Temperature in celsius : %.2f and feels like %.2f" %(cel,celfeel))
print("Pressure : "+ str(info["main"]["pressure"]))
print("Humidity : "+ str(info["main"]["humidity"]))
print("Wind Speed : "+str(info["wind"]["speed"]))
print("Country : "+str(info["sys"]["country"]))

speak("Weather description at "+ct+" is "+ str(info["weather"][0]["description"]))
speak("Temperature in celsius : %.2f and feels like %.2f" %(cel,celfeel))
speak("Pressure : "+ str(info["main"]["pressure"]))
speak("Humidity : "+ str(info["main"]["humidity"]))
speak("Wind Speed : "+str(info["wind"]["speed"]))





