#pip install azure-ai-textanalytics

from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential


cont="""
i am no so happy with the product. price is high but the design is average.
It's on you if you want to buy.
"""

def authenticate_client():
    ta_credential = AzureKeyCredential('0fbe6bcae56e46f38e9750b025e8f036')
    text_analytics_client = TextAnalyticsClient(
            endpoint='https://sohamsentiments.cognitiveservices.azure.com/', 
            credential=ta_credential) 
    return text_analytics_client

client = authenticate_client()


def sentiment_analysis_example(client):

    documents=[]
    documents.append(cont)
    response = client.analyze_sentiment(documents = documents)[0]

    pos=response.confidence_scores.positive
    neu=response.confidence_scores.neutral
    neg=response.confidence_scores.negative
    sent=None
    if(pos>neu):
        if(pos>neg):
            sent="Positive"
        else:
            sent="Negative"
    else:
        if(neu>neg):
            sent="Neutral"
        else:
            sent="Negative"
    
    print("General Document Sentiment: {}".format(sent))

    dic={"sentiment":sent,"positive":pos*100,"neutral":neu*100,"negative":neg*100}
    print(dic)

sentiment_analysis_example(client)



